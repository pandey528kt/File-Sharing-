import { useState, useCallback, useRef } from 'react';
import { UploadCloud, X, Loader2, CheckCircle2 } from 'lucide-react';
import { supabase, STORAGE_BUCKET, formatFileSize, type FileRecord } from '@/lib/supabase';

interface UploadZoneProps {
  onUploaded: (file: FileRecord) => void;
  folderId?: string | null;
}

interface UploadingFile {
  name: string;
  size: number;
  progress: number;
  status: 'uploading' | 'done' | 'error';
  error?: string;
}

export function UploadZone({ onUploaded, folderId = null }: UploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState<UploadingFile[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const generateToken = () => {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  };

  const uploadFile = useCallback(
    async (file: File) => {
      const shareToken = generateToken();
      const storagePath = `${shareToken}/${file.name}`;

      const entry: UploadingFile = {
        name: file.name,
        size: file.size,
        progress: 0,
        status: 'uploading',
      };

      setUploading((prev) => [...prev, entry]);

      try {
        const { error: uploadError } = await supabase.storage
          .from(STORAGE_BUCKET)
          .upload(storagePath, file, {
            cacheControl: '3600',
            upsert: false,
          });

        if (uploadError) throw uploadError;

        const { data: record, error: dbError } = await supabase
          .from('files')
          .insert({
            file_name: file.name,
            file_type: file.type || 'application/octet-stream',
            file_size: file.size,
            storage_path: storagePath,
            share_token: shareToken,
            folder_id: folderId,
          })
          .select()
          .single();

        if (dbError) throw dbError;

        setUploading((prev) =>
          prev.map((f) =>
            f.name === file.name && f.status === 'uploading'
              ? { ...f, progress: 100, status: 'done' }
              : f
          )
        );

        if (record) onUploaded(record as FileRecord);

        setTimeout(() => {
          setUploading((prev) => prev.filter((f) => !(f.name === file.name && f.status === 'done')));
        }, 2000);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Upload failed';
        setUploading((prev) =>
          prev.map((f) =>
            f.name === file.name && f.status === 'uploading'
              ? { ...f, status: 'error', error: message }
              : f
          )
        );
      }
    },
    [onUploaded, folderId]
  );

  const handleFiles = useCallback(
    (files: FileList | null) => {
      if (!files) return;
      Array.from(files).forEach(uploadFile);
    },
    [uploadFile]
  );

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  return (
    <div className="w-full">
      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`relative cursor-pointer rounded-2xl border-2 border-dashed transition-all duration-300 ${
          isDragging
            ? 'border-blue-500 bg-blue-50 scale-[1.01]'
            : 'border-slate-300 bg-slate-50/50 hover:border-blue-400 hover:bg-blue-50/30'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            handleFiles(e.target.files);
            e.target.value = '';
          }}
        />
        <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
          <div
            className={`mb-4 rounded-2xl p-4 transition-all duration-300 ${
              isDragging ? 'bg-blue-500 text-white scale-110' : 'bg-blue-100 text-blue-600'
            }`}
          >
            <UploadCloud size={40} strokeWidth={2} />
          </div>
          <h3 className="text-lg font-semibold text-slate-800">
            {isDragging ? 'Drop your files here' : folderId ? 'Drag & drop files to this folder' : 'Drag & drop files to share'}
          </h3>
          <p className="mt-1 text-sm text-slate-500">
            or <span className="text-blue-600 font-medium">browse</span> from your computer
          </p>
          <p className="mt-3 text-xs text-slate-400">
            Any file type up to 50 MB
          </p>
        </div>
      </div>

      {uploading.length > 0 && (
        <div className="mt-4 space-y-3">
          {uploading.map((file, idx) => (
            <div
              key={`${file.name}-${idx}`}
              className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-3 shadow-sm"
            >
              <div className="flex-shrink-0">
                {file.status === 'uploading' && (
                  <Loader2 size={20} className="animate-spin text-blue-500" />
                )}
                {file.status === 'done' && (
                  <CheckCircle2 size={20} className="text-emerald-500" />
                )}
                {file.status === 'error' && (
                  <X size={20} className="text-red-500" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-medium text-slate-700">{file.name}</p>
                  <span className="flex-shrink-0 text-xs text-slate-400">
                    {formatFileSize(file.size)}
                  </span>
                </div>
                {file.status === 'uploading' && (
                  <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-500 to-sky-400 transition-all duration-300"
                      style={{ width: '100%' }}
                    />
                  </div>
                )}
                {file.status === 'done' && (
                  <p className="mt-1 text-xs text-emerald-600">Uploaded successfully</p>
                )}
                {file.status === 'error' && (
                  <p className="mt-1 text-xs text-red-500">{file.error}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
