import { useState, useEffect, useRef } from 'react';
import { Lock, Unlock, X, Loader2, ShieldCheck, Eye, EyeOff } from 'lucide-react';

interface PasswordModalProps {
  open: boolean;
  mode: 'set' | 'enter';
  itemName?: string;
  onClose: () => void;
  onSubmit: (password: string) => Promise<void>;
}

export function PasswordModal({ open, mode, itemName, onClose, onSubmit }: PasswordModalProps) {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setPassword('');
      setConfirmPassword('');
      setError(null);
      setShowPassword(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open]);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!password) {
      setError('Please enter a password');
      return;
    }

    if (mode === 'set') {
      if (password.length < 4) {
        setError('Password must be at least 4 characters');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match');
        return;
      }
    }

    setSubmitting(true);
    try {
      await onSubmit(password);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setSubmitting(false);
    }
  };

  const isSet = mode === 'set';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`flex h-10 w-10 items-center justify-center rounded-xl text-white ${isSet ? 'bg-gradient-to-br from-slate-700 to-slate-800' : 'bg-gradient-to-br from-blue-600 to-sky-500'}`}>
              {isSet ? <Lock size={22} /> : <ShieldCheck size={22} />}
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800">
                {isSet ? 'Protect with password' : 'Enter password'}
              </h2>
              {itemName && (
                <p className="text-xs text-slate-400 truncate max-w-[200px]">{itemName}</p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="relative">
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              {isSet ? 'New password' : 'Password'}
            </label>
            <input
              ref={inputRef}
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={isSet ? 'Enter a password' : 'Enter the password to access'}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 pr-11 text-slate-800 outline-none transition-all focus:border-slate-500 focus:bg-white focus:ring-2 focus:ring-slate-100"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-[38px] text-slate-400 transition-colors hover:text-slate-600"
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          {isSet && (
            <div className="mt-4">
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Confirm password
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter the password"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-slate-800 outline-none transition-all focus:border-slate-500 focus:bg-white focus:ring-2 focus:ring-slate-100"
              />
            </div>
          )}

          {isSet && (
            <p className="mt-3 flex items-start gap-1.5 text-xs text-slate-400">
              <Lock size={12} className="mt-0.5 flex-shrink-0" />
              Anyone with the share link will need this password to view or download.
            </p>
          )}

          {error && <p className="mt-3 text-sm text-red-500">{error}</p>}

          <div className="mt-6 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2.5 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold text-white shadow-lg transition-all hover:shadow-xl active:scale-95 disabled:opacity-60 ${isSet ? 'bg-gradient-to-r from-slate-700 to-slate-800 shadow-slate-700/25' : 'bg-gradient-to-r from-blue-600 to-sky-500 shadow-blue-500/25'}`}
            >
              {submitting ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  {isSet ? 'Setting...' : 'Verifying...'}
                </>
              ) : isSet ? (
                <>
                  <Lock size={16} />
                  Set password
                </>
              ) : (
                <>
                  <Unlock size={16} />
                  Unlock
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
