import { useState, useEffect } from 'react';
import { Download, ArrowLeft, Clock, Eye, FileWarning, Loader2, Folder, FileText, Lock, ShieldCheck } from 'lucide-react';
import {
  supabase,
  STORAGE_BUCKET,
  formatFileSize,
  formatDate,
  verifyPassword,
  type FileRecord,
  type FolderRecord,
} from '@/lib/supabase';
import { FileTypeIcon } from '@/components/FileTypeIcon';
import { PasswordModal } from '@/components/PasswordModal';

interface SharePageProps {
  token: string;
  onBack: () => void;
}

export function SharePage({ token, onBack }: SharePageProps) {
  const [folder, setFolder] = useState<FolderRecord | null>(null);
  const [files, setFiles] = useState<FileRecord[]>([]);
  const [singleFile, setSingleFile] = useState<FileRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [needsPassword, setNeedsPassword] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadShared() {
      // Try folder first
      const { data: folderData } = await supabase
        .from('folders')
        .select('id, name, share_token, created_at, has_password, is_public')
        .eq('share_token', token)
        .maybeSingle();

      if (cancelled) return;

      if (folderData) {
        const folderRec = folderData as FolderRecord;
        setFolder(folderRec);
        if (!folderRec.is_public) {
          setError('This folder is private and not publicly shared');
          setLoading(false);
          return;
        }
        if (folderRec.has_password) {
          setNeedsPassword(true);
          setLoading(false);
          return;
        }
        setUnlocked(true);
        await loadFolderFiles(folderRec.id);
        if (cancelled) return;
        setLoading(false);
        return;
      }

      // Try single file
      const { data: fileData, error: queryError } = await supabase
        .from('files')
        .select('id, file_name, file_type, file_size, storage_path, share_token, download_count, created_at, expires_at, folder_id, has_password, is_public')
        .eq('share_token', token)
        .maybeSingle();

      if (cancelled) return;

      if (queryError) {
        setError('Failed to load shared content');
        setLoading(false);
        return;
      }

      if (!fileData) {
        setError('File or folder not found, or it has been deleted');
        setLoading(false);
        return;
      }

      const record = fileData as FileRecord;
      setSingleFile(record);

      if (!record.is_public) {
        setError('This file is private and not publicly shared');
        setLoading(false);
        return;
      }

      if (record.has_password) {
        setNeedsPassword(true);
        setLoading(false);
        return;
      }

      setUnlocked(true);
      if (record.file_type.startsWith('image/')) {
        const { data: urlData } = supabase.storage
          .from(STORAGE_BUCKET)
          .getPublicUrl(record.storage_path);
        setPreviewUrl(urlData.publicUrl);
      }

      setLoading(false);
    }

    loadShared();
    return () => {
      cancelled = true;
    };
  }, [token]);

  async function loadFolderFiles(folderId: string) {
    const { data: folderFiles } = await supabase
      .from('files')
      .select('id, file_name, file_type, file_size, storage_path, share_token, download_count, created_at, expires_at, folder_id, has_password, is_public')
      .eq('folder_id', folderId)
      .order('created_at', { ascending: false });
    setFiles((folderFiles as FileRecord[]) || []);
  }

  const handlePasswordSubmit = async (password: string) => {
    const type = folder ? 'folder' : 'file';
    const ok = await verifyPassword(type, token, password);
    if (ok) {
      setUnlocked(true);
      setNeedsPassword(false);
      // Now load content
      if (folder) {
        await loadFolderFiles(folder.id);
      } else if (singleFile && singleFile.file_type.startsWith('image/')) {
        const { data: urlData } = supabase.storage
          .from(STORAGE_BUCKET)
          .getPublicUrl(singleFile.storage_path);
        setPreviewUrl(urlData.publicUrl);
      }
    } else {
      throw new Error('Incorrect password. Please try again.');
    }
  };

  const handleSingleDownload = async () => {
    if (!singleFile) return;
    setDownloading(true);
    try {
      const { data } = await supabase.storage
        .from(STORAGE_BUCKET)
        .createSignedUrl(singleFile.storage_path, 3600);
      if (data?.signedUrl) {
        const a = document.createElement('a');
        a.href = data.signedUrl;
        a.download = singleFile.file_name;
        a.click();
        await supabase
          .from('files')
          .update({ download_count: singleFile.download_count + 1 })
          .eq('id', singleFile.id);
      }
    } finally {
      setDownloading(false);
    }
  };

  const handleFolderFileDownload = async (file: FileRecord) => {
    const { data } = await supabase.storage
      .from(STORAGE_BUCKET)
      .createSignedUrl(file.storage_path, 3600);
    if (data?.signedUrl) {
      const a = document.createElement('a');
      a.href = data.signedUrl;
      a.download = file.file_name;
      a.click();
      await supabase
        .from('files')
        .update({ download_count: file.download_count + 1 })
        .eq('id', file.id);
    }
  };

  const handleDownloadAll = async () => {
    for (const file of files) {
      await handleFolderFileDownload(file);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <Loader2 size={36} className="animate-spin text-blue-500" />
          <p className="text-slate-500">Loading shared content...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="max-w-md text-center">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-red-50 text-red-500">
            <FileWarning size={40} />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Not Found</h1>
          <p className="mt-2 text-slate-500">{error}</p>
          <button
            onClick={onBack}
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-slate-800 px-5 py-2.5 font-medium text-white transition-colors hover:bg-slate-700"
          >
            <ArrowLeft size={18} />
            Back to home
          </button>
        </div>
      </div>
    );
  }

  // Password gate
  if (needsPassword && !unlocked) {
    const itemName = folder ? folder.name : singleFile?.file_name;
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-slate-50 to-slate-100">
        <div className="max-w-md px-4 text-center">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-slate-700 to-slate-800 text-white shadow-lg">
            <Lock size={40} />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Password protected</h1>
          <p className="mt-2 text-slate-500">
            {itemName ? (
              <>Enter the password to access <span className="font-medium text-slate-700">{itemName}</span></>
            ) : (
              'Enter the password to access this content'
            )}
          </p>
          <div className="mt-6">
            <PasswordModal
              open={true}
              mode="enter"
              itemName={itemName}
              onClose={onBack}
              onSubmit={handlePasswordSubmit}
            />
          </div>
          <button
            onClick={onBack}
            className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-slate-400 transition-colors hover:text-slate-600"
          >
            <ArrowLeft size={16} />
            Back to home
          </button>
        </div>
      </div>
    );
  }

  // Folder share page
  if (folder) {
    const totalSize = files.reduce((sum, f) => sum + f.file_size, 0);
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
        <div className="mx-auto max-w-2xl px-4 py-12">
          <button
            onClick={onBack}
            className="mb-8 inline-flex items-center gap-2 text-sm font-medium text-slate-500 transition-colors hover:text-slate-800"
          >
            <ArrowLeft size={16} />
            Back to home
          </button>

          <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl">
            <div className="flex items-center gap-4 bg-gradient-to-r from-amber-500 to-orange-500 p-8 text-white">
              <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20">
                <Folder size={36} />
                {folder.has_password && (
                  <div className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-slate-800 text-white ring-2 ring-amber-500">
                    <Lock size={12} />
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <h1 className="text-xl font-bold break-words">{folder.name}</h1>
                <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-white/80">
                  <span>{files.length} file{files.length !== 1 ? 's' : ''}</span>
                  <span>{formatFileSize(totalSize)}</span>
                  <span className="flex items-center gap-1">
                    <Clock size={14} />
                    {formatDate(folder.created_at)}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-6">
              {files.length === 0 ? (
                <div className="flex flex-col items-center py-12 text-center">
                  <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
                    <FileText size={32} />
                  </div>
                  <p className="text-slate-500">This folder is empty</p>
                </div>
              ) : (
                <>
                  <div className="mb-4 space-y-2">
                    {files.map((file) => (
                      <div
                        key={file.id}
                        className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 transition-colors hover:bg-slate-50"
                      >
                        <FileTypeIcon type={file.file_type} size={20} className="flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium text-slate-700">{file.file_name}</p>
                          <p className="text-xs text-slate-400">{formatFileSize(file.file_size)}</p>
                        </div>
                        <button
                          onClick={() => handleFolderFileDownload(file)}
                          className="flex-shrink-0 rounded-lg p-2 text-slate-500 transition-colors hover:bg-blue-50 hover:text-blue-600"
                        >
                          <Download size={18} />
                        </button>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={handleDownloadAll}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 py-3.5 font-semibold text-white shadow-lg shadow-amber-500/25 transition-all hover:shadow-xl active:scale-[0.98]"
                  >
                    <Download size={20} />
                    Download all ({files.length})
                  </button>
                </>
              )}

              <div className="mt-6 flex items-center justify-center gap-2 text-xs text-slate-400">
                {folder.has_password ? (
                  <>
                    <ShieldCheck size={14} />
                    <span>Protected & shared via FileShare</span>
                  </>
                ) : (
                  <>
                    <Eye size={14} />
                    <span>Shared via FileShare</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Single file share page
  if (!singleFile) return null;
  const isImage = singleFile.file_type.startsWith('image/');

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      <div className="mx-auto max-w-2xl px-4 py-12">
        <button
          onClick={onBack}
          className="mb-8 inline-flex items-center gap-2 text-sm font-medium text-slate-500 transition-colors hover:text-slate-800"
        >
          <ArrowLeft size={16} />
          Back to home
        </button>

        <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl">
          {isImage && previewUrl && (
            <div className="flex items-center justify-center bg-slate-900 p-8">
              <img
                src={previewUrl}
                alt={singleFile.file_name}
                className="max-h-80 rounded-xl object-contain"
              />
            </div>
          )}

          <div className="p-8">
            <div className="flex items-start gap-5">
              <div className="relative flex-shrink-0">
                <FileTypeIcon type={singleFile.file_type} size={36} />
                {singleFile.has_password && (
                  <div className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-slate-800 text-white ring-2 ring-white">
                    <Lock size={12} />
                  </div>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <h1 className="text-xl font-bold text-slate-800 break-words">{singleFile.file_name}</h1>
                <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-500">
                  <span>{formatFileSize(singleFile.file_size)}</span>
                  <span className="flex items-center gap-1">
                    <Clock size={14} />
                    {formatDate(singleFile.created_at)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Download size={14} />
                    {singleFile.download_count} download{singleFile.download_count !== 1 ? 's' : ''}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={handleSingleDownload}
              disabled={downloading}
              className="mt-8 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-sky-500 py-3.5 font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:shadow-xl hover:shadow-blue-500/30 active:scale-[0.98] disabled:opacity-60"
            >
              {downloading ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  Preparing download...
                </>
              ) : (
                <>
                  <Download size={20} />
                  Download file
                </>
              )}
            </button>

            <div className="mt-6 flex items-center justify-center gap-2 text-xs text-slate-400">
              {singleFile.has_password ? (
                <>
                  <ShieldCheck size={14} />
                  <span>Protected & shared via FileShare</span>
                </>
              ) : (
                <>
                  <Eye size={14} />
                  <span>Shared via FileShare</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
