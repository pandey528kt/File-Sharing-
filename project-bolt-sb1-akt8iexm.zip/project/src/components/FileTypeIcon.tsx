import {
  FileText,
  FileImage,
  FileVideo,
  FileAudio,
  FileArchive,
  FileSpreadsheet,
  Monitor,
  File as FileIcon,
} from 'lucide-react';

const iconMap: Record<string, typeof FileText> = {
  image: FileImage,
  video: FileVideo,
  audio: FileAudio,
  archive: FileArchive,
  text: FileText,
  spreadsheet: FileSpreadsheet,
  presentation: Monitor,
  document: FileText,
  pdf: FileText,
  file: FileIcon,
};

const colorMap: Record<string, string> = {
  image: 'from-sky-400 to-blue-500',
  video: 'from-rose-400 to-red-500',
  audio: 'from-purple-400 to-fuchsia-500',
  archive: 'from-amber-400 to-orange-500',
  text: 'from-slate-400 to-slate-500',
  spreadsheet: 'from-emerald-400 to-green-500',
  presentation: 'from-orange-400 to-amber-500',
  document: 'from-blue-400 to-indigo-500',
  pdf: 'from-red-400 to-rose-500',
  file: 'from-gray-400 to-gray-500',
};

interface FileIconProps {
  type: string;
  size?: number;
  className?: string;
}

export function FileTypeIcon({ type, size = 24, className = '' }: FileIconProps) {
  const iconKey = getFileIconKey(type);
  const Icon = iconMap[iconKey] ?? FileIcon;
  const gradient = colorMap[iconKey] ?? colorMap.file;

  return (
    <div
      className={`inline-flex items-center justify-center rounded-xl bg-gradient-to-br ${gradient} text-white shadow-sm ${className}`}
      style={{ width: size + 16, height: size + 16 }}
    >
      <Icon size={size} strokeWidth={2} />
    </div>
  );
}

export function getFileIconKey(type: string): string {
  if (type.startsWith('image/')) return 'image';
  if (type.startsWith('video/')) return 'video';
  if (type.startsWith('audio/')) return 'audio';
  if (type.includes('pdf')) return 'pdf';
  if (type.includes('zip') || type.includes('compressed') || type.includes('tar') || type.includes('rar') || type.includes('7z'))
    return 'archive';
  if (type.includes('text') || type.includes('json') || type.includes('xml') || type.includes('javascript') || type.includes('typescript'))
    return 'text';
  if (type.includes('spreadsheet') || type.includes('excel') || type.includes('csv')) return 'spreadsheet';
  if (type.includes('presentation') || type.includes('powerpoint')) return 'presentation';
  if (type.includes('document') || type.includes('word') || type.includes('msword')) return 'document';
  return 'file';
}
