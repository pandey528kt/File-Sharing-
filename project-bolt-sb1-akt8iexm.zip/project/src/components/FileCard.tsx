import { useState } from 'react';
import { Copy, Check, Trash2, Download, Eye, Clock, Lock, Unlock, Loader2, Globe, EyeOff } from 'lucide-react';
import { supabase, STORAGE_BUCKET, formatFileSize, formatDate, setPassword, removePassword, type FileRecord } from '@/lib/supabase';
import { FileTypeIcon } from '@/components/FileTypeIcon';
import { PasswordModal } from '@/components/PasswordModal';

interface FileCardProps {
  file: FileRecord;
  onDeleted: (id: string) => void;
  onView: (token: string) => void;
  onPasswordChanged: (id: string, hasPassword: boolean) => void;
  onVisibilityChanged: (id: string, isPublic: boolean) => void;
}

export function FileCard({ file, onDeleted, onView, onPasswordChanged, onVisibilityChanged }: FileCardProps) {
  const [copied, setCopied] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [visibilityLoading, setVisibilityLoading] = useState(false);

  const shareUrl = `${window.location.origin}/#/s/${file.share_token}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = shareUrl;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await supabase.storage.from(STORAGE_BUCKET).remove([file.storage_path]);
      await supabase.from('files').delete().eq('id', file.id);
      onDeleted(file.id);
    } catch {
      setDeleting(false);
    }
  };

  const handleDownload = async () => {
    const { data } = await supabase.storage
      .from(STORAGE_BUCKET)
      .createSignedUrl(file.storage_path, 3600);

    if (data?.signedUrl) {
      const a = document.createElement('a');
      a.href = data.signedUrl;
      a.download = file.file_name;
      a.click();
    }
  };

  const handleToggleVisibility = async () => {
    setVisibilityLoading(true);
    const newValue = !file.is_public;
    try {
      await supabase.from('files').update({ is_public: newValue }).eq('id', file.id);
      onVisibilityChanged(file.id, newValue);
    } catch {
      // ignore
    } finally {
      setVisibilityLoading(false);
    }
  };

  const handleSetPassword = async (password: string) => {
    setPasswordLoading(true);
    try {
      await setPassword('file', file.id, password);
      onPasswordChanged(file.id, true);
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleRemovePassword = async () => {
    setPasswordLoading(true);
    try {
      await removePassword('file', file.id);
      onPasswordChanged(file.id, false);
    } catch {
      // ignore
    } finally {
      setPasswordLoading(false);
    }
  };

  return (
    <>
      <div className="group relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-md hover:border-slate-300">
        <div className="flex items-start gap-4">
          <div className="relative flex-shrink-0">
            <FileTypeIcon type={file.file_type} size={28} />
            {file.has_password && (
              <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-slate-700 text-white shadow-sm ring-2 ring-white">
                <Lock size={10} />
              </div>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="truncate font-semibold text-slate-800" title={file.file_name}>
              {file.file_name}
            </h3>
            <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
              <span>{formatFileSize(file.file_size)}</span>
              <span className="text-slate-300">|</span>
              <span className="flex items-center gap-1">
                <Clock size={12} />
                {formatDate(file.created_at)}
              </span>
              <span className="text-slate-300">|</span>
              <span>{file.download_count} download{file.download_count !== 1 ? 's' : ''}</span>
              {file.has_password && (
                <>
                  <span className="text-slate-300">|</span>
                  <span className="flex items-center gap-1 font-medium text-slate-600">
                    <Lock size={10} />
                    Protected
                  </span>
                </>
              )}
              <span className="text-slate-300">|</span>
              <span className={`flex items-center gap-1 font-medium ${file.is_public ? 'text-emerald-600' : 'text-slate-400'}`}>
                {file.is_public ? <Globe size={10} /> : <EyeOff size={10} />}
                {file.is_public ? 'Public' : 'Private'}
              </span>
            </div>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-2">
          <div className={`flex min-w-0 flex-1 items-center gap-1 rounded-lg border px-3 py-2 ${file.is_public ? 'border-slate-200 bg-slate-50' : 'border-slate-200 bg-slate-100/50'}`}>
            <span className={`truncate text-xs font-mono ${file.is_public ? 'text-slate-500' : 'text-slate-400 line-through'}`}>{shareUrl}</span>
          </div>
          <button
            onClick={handleCopy}
            disabled={!file.is_public}
            className="flex-shrink-0 rounded-lg bg-blue-600 px-3 py-2 text-white transition-all hover:bg-blue-700 active:scale-95 disabled:opacity-40"
            title={file.is_public ? 'Copy share link' : 'Make public to enable link'}
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
        </div>

        {copied && (
          <p className="mt-2 text-xs text-emerald-600 font-medium">Link copied to clipboard!</p>
        )}

        <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3">
          <button
            onClick={() => onView(file.share_token)}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100"
          >
            <Eye size={15} />
            View
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100"
          >
            <Download size={15} />
            Download
          </button>
          <button
            onClick={handleToggleVisibility}
            disabled={visibilityLoading}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors disabled:opacity-50 ${file.is_public ? 'text-emerald-600 hover:bg-emerald-50' : 'text-slate-500 hover:bg-slate-100'}`}
            title={file.is_public ? 'Make private — disable share link' : 'Make public — enable share link'}
          >
            {visibilityLoading ? (
              <Loader2 size={15} className="animate-spin" />
            ) : file.is_public ? (
              <>
                <Globe size={15} />
                <span className="hidden sm:inline">Public</span>
              </>
            ) : (
              <>
                <EyeOff size={15} />
                <span className="hidden sm:inline">Private</span>
              </>
            )}
          </button>
          <button
            onClick={() => file.has_password ? handleRemovePassword() : setShowPasswordModal(true)}
            disabled={passwordLoading}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100 disabled:opacity-50"
            title={file.has_password ? 'Remove password' : 'Add password'}
          >
            {passwordLoading ? (
              <Loader2 size={15} className="animate-spin" />
            ) : file.has_password ? (
              <>
                <Unlock size={15} />
                <span className="hidden sm:inline">Remove lock</span>
              </>
            ) : (
              <>
                <Lock size={15} />
                <span className="hidden sm:inline">Add password</span>
              </>
            )}
          </button>
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="ml-auto flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium text-red-500 transition-colors hover:bg-red-50 disabled:opacity-50"
          >
            <Trash2 size={15} />
            Delete
          </button>
        </div>
      </div>

      <PasswordModal
        open={showPasswordModal}
        mode="set"
        itemName={file.file_name}
        onClose={() => setShowPasswordModal(false)}
        onSubmit={handleSetPassword}
      />
    </>
  );
}
