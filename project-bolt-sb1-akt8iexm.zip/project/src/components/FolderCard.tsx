import { useState } from 'react';
import { Folder, Copy, Check, Trash2, ChevronRight, Clock, FileText, Lock, Unlock, Loader2, Globe, EyeOff } from 'lucide-react';
import { supabase, formatDate, setPassword, removePassword, type FolderRecord } from '@/lib/supabase';
import { PasswordModal } from '@/components/PasswordModal';

interface FolderCardProps {
  folder: FolderRecord;
  fileCount: number;
  onOpen: (id: string) => void;
  onDeleted: (id: string) => void;
  onPasswordChanged: (id: string, hasPassword: boolean) => void;
  onVisibilityChanged: (id: string, isPublic: boolean) => void;
}

export function FolderCard({ folder, fileCount, onOpen, onDeleted, onPasswordChanged, onVisibilityChanged }: FolderCardProps) {
  const [copied, setCopied] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [visibilityLoading, setVisibilityLoading] = useState(false);

  const shareUrl = `${window.location.origin}/#/s/${folder.share_token}`;

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = shareUrl;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleting(true);
    try {
      await supabase.from('folders').delete().eq('id', folder.id);
      onDeleted(folder.id);
    } catch {
      setDeleting(false);
    }
  };

  const handleToggleVisibility = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setVisibilityLoading(true);
    const newValue = !folder.is_public;
    try {
      await supabase.from('folders').update({ is_public: newValue }).eq('id', folder.id);
      onVisibilityChanged(folder.id, newValue);
    } catch {
      // ignore
    } finally {
      setVisibilityLoading(false);
    }
  };

  const handleSetPassword = async (password: string) => {
    setPasswordLoading(true);
    try {
      await setPassword('folder', folder.id, password);
      onPasswordChanged(folder.id, true);
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleRemovePassword = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setPasswordLoading(true);
    try {
      await removePassword('folder', folder.id);
      onPasswordChanged(folder.id, false);
    } catch {
      // ignore
    } finally {
      setPasswordLoading(false);
    }
  };

  return (
    <>
      <div
        onClick={() => onOpen(folder.id)}
        className="group relative cursor-pointer overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-md hover:border-amber-300"
      >
        <div className="flex items-start gap-4">
          <div className="relative flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow-sm">
            <Folder size={26} strokeWidth={2} />
            {folder.has_password && (
              <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-slate-700 text-white shadow-sm ring-2 ring-white">
                <Lock size={10} />
              </div>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="truncate font-semibold text-slate-800" title={folder.name}>
              {folder.name}
            </h3>
            <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
              <span className="flex items-center gap-1">
                <FileText size={12} />
                {fileCount} file{fileCount !== 1 ? 's' : ''}
              </span>
              <span className="text-slate-300">|</span>
              <span className="flex items-center gap-1">
                <Clock size={12} />
                {formatDate(folder.created_at)}
              </span>
              {folder.has_password && (
                <>
                  <span className="text-slate-300">|</span>
                  <span className="flex items-center gap-1 font-medium text-slate-600">
                    <Lock size={10} />
                    Protected
                  </span>
                </>
              )}
              <span className="text-slate-300">|</span>
              <span className={`flex items-center gap-1 font-medium ${folder.is_public ? 'text-emerald-600' : 'text-slate-400'}`}>
                {folder.is_public ? <Globe size={10} /> : <EyeOff size={10} />}
                {folder.is_public ? 'Public' : 'Private'}
              </span>
            </div>
          </div>
          <ChevronRight size={20} className="flex-shrink-0 text-slate-300 transition-transform group-hover:translate-x-1 group-hover:text-amber-500" />
        </div>

        <div className="mt-4 flex items-center gap-2 border-t border-slate-100 pt-3" onClick={(e) => e.stopPropagation()}>
          <div className={`flex min-w-0 flex-1 items-center gap-1 rounded-lg border px-3 py-2 ${folder.is_public ? 'border-slate-200 bg-slate-50' : 'border-slate-200 bg-slate-100/50'}`}>
            <span className={`truncate text-xs font-mono ${folder.is_public ? 'text-slate-500' : 'text-slate-400 line-through'}`}>{shareUrl}</span>
          </div>
          <button
            onClick={handleCopy}
            disabled={!folder.is_public}
            className="flex-shrink-0 rounded-lg bg-amber-500 px-3 py-2 text-white transition-all hover:bg-amber-600 active:scale-95 disabled:opacity-40"
            title={folder.is_public ? 'Copy folder share link' : 'Make public to enable link'}
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleToggleVisibility}
            disabled={visibilityLoading}
            className={`flex-shrink-0 rounded-lg px-3 py-2 transition-colors disabled:opacity-50 ${folder.is_public ? 'text-emerald-600 hover:bg-emerald-50' : 'text-slate-500 hover:bg-slate-100'}`}
            title={folder.is_public ? 'Make private — disable share link' : 'Make public — enable share link'}
          >
            {visibilityLoading ? (
              <Loader2 size={16} className="animate-spin" />
            ) : folder.is_public ? (
              <Globe size={16} />
            ) : (
              <EyeOff size={16} />
            )}
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); folder.has_password ? handleRemovePassword(e) : setShowPasswordModal(true); }}
            disabled={passwordLoading}
            className="flex-shrink-0 rounded-lg px-3 py-2 text-slate-600 transition-colors hover:bg-slate-100 disabled:opacity-50"
            title={folder.has_password ? 'Remove password' : 'Add password'}
          >
            {passwordLoading ? (
              <Loader2 size={16} className="animate-spin" />
            ) : folder.has_password ? (
              <Unlock size={16} />
            ) : (
              <Lock size={16} />
            )}
          </button>
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="flex-shrink-0 rounded-lg px-3 py-2 text-red-500 transition-colors hover:bg-red-50 disabled:opacity-50"
            title="Delete folder"
          >
            <Trash2 size={16} />
          </button>
        </div>

        {copied && (
          <p className="mt-2 text-xs text-emerald-600 font-medium">Link copied to clipboard!</p>
        )}
      </div>

      <PasswordModal
        open={showPasswordModal}
        mode="set"
        itemName={folder.name}
        onClose={() => setShowPasswordModal(false)}
        onSubmit={handleSetPassword}
      />
    </>
  );
}
