import { useState, useEffect, useCallback } from 'react';
import {
  Share2,
  FileStack,
  Zap,
  ShieldCheck,
  Github,
  ArrowRight,
  FolderPlus,
  Home,
  ChevronRight,
} from 'lucide-react';
import {
  supabase,
  formatFileSize,
  type FileRecord,
  type FolderRecord,
} from '@/lib/supabase';
import { UploadZone } from '@/components/UploadZone';
import { FileCard } from '@/components/FileCard';
import { FolderCard } from '@/components/FolderCard';
import { SharePage } from '@/components/SharePage';
import { CreateFolderModal } from '@/components/CreateFolderModal';

type Route =
  | { name: 'home' }
  | { name: 'folder'; id: string }
  | { name: 'share'; token: string };

function parseHash(): Route {
  const hash = window.location.hash.replace(/^#\/?/, '');
  if (hash.startsWith('s/')) {
    const token = hash.slice(2);
    if (token) return { name: 'share', token };
  }
  if (hash.startsWith('f/')) {
    const id = hash.slice(2);
    if (id) return { name: 'folder', id };
  }
  return { name: 'home' };
}

function App() {
  const [route, setRoute] = useState<Route>(parseHash());
  const [files, setFiles] = useState<FileRecord[]>([]);
  const [folders, setFolders] = useState<FolderRecord[]>([]);
  const [currentFolder, setCurrentFolder] = useState<FolderRecord | null>(null);
  const [loadingData, setLoadingData] = useState(true);
  const [stats, setStats] = useState({ total: 0, size: 0, downloads: 0 });
  const [showFolderModal, setShowFolderModal] = useState(false);
  const [folderFileCounts, setFolderFileCounts] = useState<Map<string, number>>(new Map());

  useEffect(() => {
    const onHashChange = () => setRoute(parseHash());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigateTo = (newRoute: Route) => {
    if (newRoute.name === 'home') {
      window.location.hash = '';
    } else if (newRoute.name === 'share') {
      window.location.hash = `/s/${newRoute.token}`;
    } else if (newRoute.name === 'folder') {
      window.location.hash = `/f/${newRoute.id}`;
    }
    setRoute(newRoute);
  };

  const loadHomeData = useCallback(async () => {
    setLoadingData(true);

    const [filesRes, foldersRes] = await Promise.all([
      supabase
        .from('files')
        .select('*')
        .is('folder_id', null)
        .order('created_at', { ascending: false })
        .limit(50),
      supabase
        .from('folders')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50),
    ]);

    const homeFiles = (filesRes.data as FileRecord[]) || [];
    const homeFolders = (foldersRes.data as FolderRecord[]) || [];
    setFiles(homeFiles);
    setFolders(homeFolders);

    // Fetch file counts per folder
    if (homeFolders.length > 0) {
      const counts = new Map<string, number>();
      await Promise.all(
        homeFolders.map(async (folder) => {
          const { count } = await supabase
            .from('files')
            .select('*', { count: 'exact', head: true })
            .eq('folder_id', folder.id);
          counts.set(folder.id, count ?? 0);
        })
      );
      setFolderFileCounts(counts);
    } else {
      setFolderFileCounts(new Map());
    }

    // Fetch total stats across ALL files
    const { data: allFiles } = await supabase.from('files').select('file_size, download_count');
    if (allFiles) {
      const totalSize = (allFiles as { file_size: number }[]).reduce((s, f) => s + f.file_size, 0);
      const totalDownloads = (allFiles as { download_count: number }[]).reduce(
        (s, f) => s + f.download_count,
        0
      );
      setStats({ total: allFiles.length, size: totalSize, downloads: totalDownloads });
    }

    setLoadingData(false);
  }, []);

  const loadFolderData = useCallback(async (folderId: string) => {
    setLoadingData(true);

    const [folderRes, filesRes] = await Promise.all([
      supabase.from('folders').select('*').eq('id', folderId).maybeSingle(),
      supabase
        .from('files')
        .select('*')
        .eq('folder_id', folderId)
        .order('created_at', { ascending: false }),
    ]);

    setCurrentFolder((folderRes.data as FolderRecord) || null);
    setFiles((filesRes.data as FileRecord[]) || []);
    setFolders([]);
    setLoadingData(false);
  }, []);

  useEffect(() => {
    if (route.name === 'home') {
      setCurrentFolder(null);
      loadHomeData();
    } else if (route.name === 'folder') {
      loadFolderData(route.id);
    }
  }, [route, loadHomeData, loadFolderData]);

  const handleUploaded = (file: FileRecord) => {
    setFiles((prev) => [file, ...prev]);
    setStats((prev) => ({
      total: prev.total + 1,
      size: prev.size + file.file_size,
      downloads: prev.downloads,
    }));
  };

  const handleFileDeleted = (id: string) => {
    setFiles((prev) => {
      const deleted = prev.find((f) => f.id === id);
      if (deleted) {
        setStats((s) => ({
          total: s.total - 1,
          size: s.size - deleted.file_size,
          downloads: s.downloads - deleted.download_count,
        }));
      }
      return prev.filter((f) => f.id !== id);
    });
  };

  const handleFolderDeleted = (id: string) => {
    setFolders((prev) => prev.filter((f) => f.id !== id));
  };

  const handleFilePasswordChanged = (id: string, hasPassword: boolean) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, has_password: hasPassword } : f))
    );
  };

  const handleFolderPasswordChanged = (id: string, hasPassword: boolean) => {
    setFolders((prev) =>
      prev.map((f) => (f.id === id ? { ...f, has_password: hasPassword } : f))
    );
  };

  const handleFileVisibilityChanged = (id: string, isPublic: boolean) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, is_public: isPublic } : f))
    );
  };

  const handleFolderVisibilityChanged = (id: string, isPublic: boolean) => {
    setFolders((prev) =>
      prev.map((f) => (f.id === id ? { ...f, is_public: isPublic } : f))
    );
  };

  const handleCreateFolder = async (name: string) => {
    const { data, error } = await supabase
      .from('folders')
      .insert({ name })
      .select()
      .single();

    if (error) throw error;
    if (data) {
      setFolders((prev) => [data as FolderRecord, ...prev]);
    }
  };

  if (route.name === 'share') {
    return <SharePage token={route.token} onBack={() => navigateTo({ name: 'home' })} />;
  }

  const isFolderView = route.name === 'folder' && currentFolder;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <button
            onClick={() => navigateTo({ name: 'home' })}
            className="flex items-center gap-2.5"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-sky-500 text-white shadow-md shadow-blue-500/25">
              <Share2 size={20} />
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-800">
              File<span className="text-blue-600">Share</span>
            </span>
          </button>
          <a
            href="https://github.com"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100"
          >
            <Github size={18} />
            <span className="hidden sm:inline">Source</span>
          </a>
        </div>
      </header>

      {/* Hero — only on home */}
      {route.name === 'home' && (
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-blue-50/50 to-transparent" />
          <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-blue-200/30 blur-3xl" />
          <div className="absolute -top-24 -left-24 h-72 w-72 rounded-full bg-sky-200/20 blur-3xl" />

          <div className="relative mx-auto max-w-6xl px-4 pt-16 pb-12 text-center">
            <div className="mx-auto mb-5 flex w-fit items-center gap-2 rounded-full border border-blue-200 bg-blue-50 px-4 py-1.5 text-sm font-medium text-blue-700">
              <Zap size={14} />
              Fast, simple, free file sharing
            </div>
            <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl md:text-6xl">
              Share files in
              <span className="bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent"> seconds</span>
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-base text-slate-500 sm:text-lg">
              Upload any file and get an instant shareable link. No sign-up required, no waiting.
            </p>
          </div>
        </section>
      )}

      {/* Breadcrumb for folder view */}
      {isFolderView && (
        <div className="border-b border-slate-200 bg-white">
          <div className="mx-auto flex max-w-6xl items-center gap-1.5 px-4 py-3 text-sm">
            <button
              onClick={() => navigateTo({ name: 'home' })}
              className="flex items-center gap-1.5 font-medium text-slate-500 transition-colors hover:text-blue-600"
            >
              <Home size={15} />
              Home
            </button>
            <ChevronRight size={15} className="text-slate-300" />
            <span className="font-medium text-slate-800">{currentFolder!.name}</span>
          </div>
        </div>
      )}

      {/* Main content */}
      <main className="mx-auto max-w-6xl px-4 pb-20 pt-8">
        <div className="grid gap-8 lg:grid-cols-5">
          {/* Upload section */}
          <div className="lg:col-span-2">
            <div className="sticky top-24 space-y-4">
              {route.name === 'home' && (
                <button
                  onClick={() => setShowFolderModal(true)}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border-2 border-amber-300 bg-amber-50 py-3 font-semibold text-amber-700 transition-all hover:bg-amber-100 active:scale-[0.98]"
                >
                  <FolderPlus size={20} />
                  New folder
                </button>
              )}
              <div>
                <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-slate-800">
                  <ArrowRight size={20} className="text-blue-600" />
                  {isFolderView ? 'Upload to folder' : 'Upload'}
                </h2>
                <UploadZone
                  onUploaded={handleUploaded}
                  folderId={isFolderView ? currentFolder!.id : null}
                />
              </div>
            </div>
          </div>

          {/* Files & folders list */}
          <div className="lg:col-span-3">
            {/* Folders — only on home */}
            {route.name === 'home' && folders.length > 0 && (
              <div className="mb-8">
                <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-slate-800">
                  <FolderPlus size={20} className="text-amber-500" />
                  Folders
                </h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  {folders.map((folder) => (
                    <FolderCard
                      key={folder.id}
                      folder={folder}
                      fileCount={folderFileCounts.get(folder.id) ?? 0}
                      onOpen={(id) => navigateTo({ name: 'folder', id })}
                      onDeleted={handleFolderDeleted}
                      onPasswordChanged={handleFolderPasswordChanged}
                      onVisibilityChanged={handleFolderVisibilityChanged}
                    />
                  ))}
                </div>
              </div>
            )}

            <div className="mb-4 flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-lg font-bold text-slate-800">
                <FileStack size={20} className="text-blue-600" />
                {isFolderView ? 'Files in folder' : 'Shared files'}
              </h2>
              {files.length > 0 && (
                <span className="text-sm text-slate-400">{files.length} file{files.length !== 1 ? 's' : ''}</span>
              )}
            </div>

            {loadingData ? (
              <div className="flex items-center justify-center py-20">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-200 border-t-blue-500" />
              </div>
            ) : files.length === 0 && folders.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-white py-20 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
                  <FileStack size={32} />
                </div>
                <h3 className="font-semibold text-slate-700">
                  {isFolderView ? 'This folder is empty' : 'No files shared yet'}
                </h3>
                <p className="mt-1 text-sm text-slate-400">
                  {isFolderView ? 'Upload files to this folder' : 'Upload a file or create a folder to get started'}
                </p>
              </div>
            ) : files.length === 0 && isFolderView ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-white py-20 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
                  <FileStack size={32} />
                </div>
                <h3 className="font-semibold text-slate-700">This folder is empty</h3>
                <p className="mt-1 text-sm text-slate-400">Upload files to this folder to get started</p>
              </div>
            ) : (
              <div className="space-y-4">
                {files.map((file) => (
                  <FileCard
                    key={file.id}
                    file={file}
                    onDeleted={handleFileDeleted}
                    onView={(token) => navigateTo({ name: 'share', token })}
                    onPasswordChanged={handleFilePasswordChanged}
                    onVisibilityChanged={handleFileVisibilityChanged}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Stats — only on home */}
        {route.name === 'home' && stats.total > 0 && (
          <div className="mt-16 grid grid-cols-3 gap-4 sm:gap-8">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm">
              <p className="text-3xl font-extrabold text-slate-800">{stats.total}</p>
              <p className="mt-1 text-sm text-slate-500">Files shared</p>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm">
              <p className="text-3xl font-extrabold text-slate-800">{formatFileSize(stats.size)}</p>
              <p className="mt-1 text-sm text-slate-500">Total size</p>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm">
              <p className="text-3xl font-extrabold text-slate-800">{stats.downloads}</p>
              <p className="mt-1 text-sm text-slate-500">Downloads</p>
            </div>
          </div>
        )}

        {/* Features — only on home */}
        {route.name === 'home' && (
          <div className="mt-20 grid gap-8 sm:grid-cols-3">
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                <Zap size={26} />
              </div>
              <h3 className="font-bold text-slate-800">Lightning fast</h3>
              <p className="mt-2 text-sm text-slate-500">
                Upload and share instantly. Get a link the moment your file is ready.
              </p>
            </div>
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600">
                <ShieldCheck size={26} />
              </div>
              <h3 className="font-bold text-slate-800">Secure storage</h3>
              <p className="mt-2 text-sm text-slate-500">
                Files are stored safely and only accessible through your unique share link.
              </p>
            </div>
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-600">
                <Share2 size={26} />
              </div>
              <h3 className="font-bold text-slate-800">Easy sharing</h3>
              <p className="mt-2 text-sm text-slate-500">
                Copy the link and send it to anyone. They can download without any account.
              </p>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-8 text-center text-sm text-slate-400">
          <p>FileShare — Simple, fast file sharing</p>
        </div>
      </footer>

      <CreateFolderModal
        open={showFolderModal}
        onClose={() => setShowFolderModal(false)}
        onCreate={handleCreateFolder}
      />
    </div>
  );
}

export default App;
