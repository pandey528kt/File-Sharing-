import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const STORAGE_BUCKET = 'shared-files';

export interface FileRecord {
  id: string;
  file_name: string;
  file_type: string;
  file_size: number;
  storage_path: string;
  share_token: string;
  download_count: number;
  created_at: string;
  expires_at: string | null;
  folder_id: string | null;
  has_password: boolean;
  is_public: boolean;
}

export interface FolderRecord {
  id: string;
  name: string;
  share_token: string;
  created_at: string;
  has_password: boolean;
  is_public: boolean;
}

const FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/password-protect`;

function getAuthHeaders() {
  return {
    Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
  };
}

export async function setPassword(type: 'file' | 'folder', id: string, password: string): Promise<void> {
  const res = await fetch(FUNCTION_URL, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ action: 'set', type, id, password }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to set password');
  }
}

export async function removePassword(type: 'file' | 'folder', id: string): Promise<void> {
  const res = await fetch(FUNCTION_URL, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ action: 'remove', type, id }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to remove password');
  }
}

export async function verifyPassword(type: 'file' | 'folder', token: string, password: string): Promise<boolean> {
  const res = await fetch(FUNCTION_URL, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ action: 'verify', type, token, password }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || 'Verification failed');
  }
  return data.verified === true;
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

export function formatDate(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffMin < 1) return 'just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHr < 24) return `${diffHr}h ago`;
  if (diffDay < 30) return `${diffDay}d ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function getFileIcon(type: string): string {
  if (type.startsWith('image/')) return 'image';
  if (type.startsWith('video/')) return 'video';
  if (type.startsWith('audio/')) return 'audio';
  if (type.includes('pdf')) return 'pdf';
  if (type.includes('zip') || type.includes('compressed')) return 'archive';
  if (type.includes('text') || type.includes('json') || type.includes('xml')) return 'text';
  if (type.includes('spreadsheet') || type.includes('excel') || type.includes('csv')) return 'spreadsheet';
  if (type.includes('presentation') || type.includes('powerpoint')) return 'presentation';
  if (type.includes('document') || type.includes('word')) return 'document';
  return 'file';
}
