/*
# File Sharing - Storage Bucket

1. Storage
- Create public bucket `shared-files` for storing uploaded files.
- Public read access so anyone with a share link can download.
- Allow anon uploads.
2. Notes
- Files are stored at path: {share_token}/{file_name}
- Public URLs allow direct download via share links.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('shared-files', 'shared-files', true)
ON CONFLICT (id) DO NOTHING;

-- Allow anyone to upload to the shared-files bucket
DROP POLICY IF EXISTS "anon_upload_shared_files" ON storage.objects;
CREATE POLICY "anon_upload_shared_files" ON storage.objects
FOR INSERT TO anon, authenticated
WITH CHECK (bucket_id = 'shared-files');

-- Allow anyone to read (download) from the shared-files bucket
DROP POLICY IF EXISTS "anon_read_shared_files" ON storage.objects;
CREATE POLICY "anon_read_shared_files" ON storage.objects
FOR SELECT TO anon, authenticated
USING (bucket_id = 'shared-files');

-- Allow anyone to delete from shared-files bucket
DROP POLICY IF EXISTS "anon_delete_shared_files" ON storage.objects;
CREATE POLICY "anon_delete_shared_files" ON storage.objects
FOR DELETE TO anon, authenticated
USING (bucket_id = 'shared-files');
