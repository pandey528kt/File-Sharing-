/*
# File Sharing - Folders table

1. New Tables
- `folders`
  - `id` (uuid, primary key)
  - `name` (text, folder name)
  - `share_token` (text, unique token for sharing an entire folder)
  - `created_at` (timestamptz)
2. Modified Tables
- `files`
  - Add `folder_id` (uuid, nullable, references folders.id ON DELETE SET NULL)
  - Add `share_token` uniqueness constraint (already unique by default, explicit constraint added)
3. Security
- Enable RLS on `folders`.
- Allow anon + authenticated CRUD (no-auth app).
4. Notes
- Files can optionally belong to a folder via `folder_id`.
- Deleting a folder sets `folder_id` to NULL on its files (they become unfiled).
- Folders get their own share_token so an entire folder can be shared via /#/s/{token}.
*/

CREATE TABLE IF NOT EXISTS folders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  share_token text NOT NULL DEFAULT encode(gen_random_bytes(16), 'hex'),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE folders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_folders" ON folders;
CREATE POLICY "anon_select_folders" ON folders FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_folders" ON folders;
CREATE POLICY "anon_insert_folders" ON folders FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_folders" ON folders;
CREATE POLICY "anon_update_folders" ON folders FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_folders" ON folders;
CREATE POLICY "anon_delete_folders" ON folders FOR DELETE
TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_folders_share_token ON folders (share_token);

-- Add folder_id column to files (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'files' AND column_name = 'folder_id'
  ) THEN
    ALTER TABLE files ADD COLUMN folder_id uuid REFERENCES folders(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_files_folder_id ON files (folder_id);
