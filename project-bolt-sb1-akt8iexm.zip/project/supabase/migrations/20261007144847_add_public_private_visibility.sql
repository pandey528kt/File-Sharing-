/*
# File Sharing - Public/Private share visibility

1. Modified Tables
- `files`: add `is_public` (boolean, default true) — when false, the share link is disabled
- `folders`: add `is_public` (boolean, default true) — when false, the share link is disabled
2. Security
- No RLS policy changes. The is_public flag is checked client-side in the SharePage.
- Private items are still visible in the dashboard (anon can read all rows by design for this no-auth app),
  but the SharePage shows a "not available" screen when is_public is false.
3. Notes
- New uploads and folders default to is_public = true (public share).
- Users can toggle between public and private from the file/folder card.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'files' AND column_name = 'is_public'
  ) THEN
    ALTER TABLE files ADD COLUMN is_public boolean NOT NULL DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'folders' AND column_name = 'is_public'
  ) THEN
    ALTER TABLE folders ADD COLUMN is_public boolean NOT NULL DEFAULT true;
  END IF;
END $$;
