/*
# File Sharing - Password protection for files and folders

1. Modified Tables
- `files`: add `has_password` (boolean, default false) and `password_hash` (text, nullable)
- `folders`: add `has_password` (boolean, default false) and `password_hash` (text, nullable)
2. Security
- No RLS policy changes needed (existing anon CRUD policies remain).
- Password hashes are never exposed to the client — the edge function handles hashing/verification server-side.
3. Notes
- `has_password` is a boolean flag the client can read to show a lock icon.
- `password_hash` stores a SHA-256 hash (computed in the edge function) and is NOT selected in client queries.
- Password setting, removal, and verification all go through the `password-protect` edge function using the service role key.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'files' AND column_name = 'has_password'
  ) THEN
    ALTER TABLE files ADD COLUMN has_password boolean NOT NULL DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'files' AND column_name = 'password_hash'
  ) THEN
    ALTER TABLE files ADD COLUMN password_hash text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'folders' AND column_name = 'has_password'
  ) THEN
    ALTER TABLE folders ADD COLUMN has_password boolean NOT NULL DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'folders' AND column_name = 'password_hash'
  ) THEN
    ALTER TABLE folders ADD COLUMN password_hash text;
  END IF;
END $$;
