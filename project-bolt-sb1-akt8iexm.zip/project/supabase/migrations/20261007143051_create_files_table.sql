/*
# File Sharing - Tables and Storage

1. New Tables
- `files`
- `id` (uuid, primary key)
- `file_name` (text, name of the uploaded file)
- `file_type` (text, MIME type)
- `file_size` (bigint, size in bytes)
- `storage_path` (text, path in the storage bucket)
- `share_token` (text, unique token for public sharing)
- `download_count` (integer, default 0, tracks downloads)
- `created_at` (timestamptz, when file was uploaded)
- `expires_at` (timestamptz, optional expiry date)
2. Security
- Enable RLS on `files`.
- Allow anon + authenticated CRUD since this is a no-auth file sharing app.
- Storage bucket `shared-files` is public for reads; uploads via anon key.
3. Notes
- share_token is used to construct shareable URLs like /s/{token}
- download_count is incremented each time someone downloads via the share link
*/

CREATE TABLE IF NOT EXISTS files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_name text NOT NULL,
  file_type text NOT NULL DEFAULT 'application/octet-stream',
  file_size bigint NOT NULL DEFAULT 0,
  storage_path text NOT NULL,
  share_token text NOT NULL DEFAULT encode(gen_random_bytes(16), 'hex'),
  download_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz
);

ALTER TABLE files ENABLE ROW LEVEL SECURITY;

-- SELECT: anyone can view file metadata (needed for share links to work)
DROP POLICY IF EXISTS "anon_select_files" ON files;
CREATE POLICY "anon_select_files" ON files FOR SELECT
TO anon, authenticated USING (true);

-- INSERT: anyone can upload files
DROP POLICY IF EXISTS "anon_insert_files" ON files;
CREATE POLICY "anon_insert_files" ON files FOR INSERT
TO anon, authenticated WITH CHECK (true);

-- UPDATE: anyone can update (increment download count, etc.)
DROP POLICY IF EXISTS "anon_update_files" ON files;
CREATE POLICY "anon_update_files" ON files FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

-- DELETE: anyone can delete files
DROP POLICY IF EXISTS "anon_delete_files" ON files;
CREATE POLICY "anon_delete_files" ON files FOR DELETE
TO anon, authenticated USING (true);

-- Index for fast share token lookups
CREATE INDEX IF NOT EXISTS idx_files_share_token ON files (share_token);
CREATE INDEX IF NOT EXISTS idx_files_created_at ON files (created_at DESC);
